package com.project.carventure;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collection;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.project.carventure.address.AddressDao;
import com.project.carventure.transaction.Transaction;
import com.project.carventure.user.LoginDto;
import com.project.carventure.user.User;
import com.project.carventure.user.UserDao;
import com.project.carventure.user.UserDto;
import com.project.carventure.user.UserException;
import com.project.carventure.user.UserServiceImplementation;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplementationTest {

    @Mock
    private UserDao userDao;

    @Mock
    private AddressDao addressDao;

    @InjectMocks
    private UserServiceImplementation userService;

    private User user;
    private LoginDto loginDto;
    private UserDto userDto;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setId(1);
        user.setEmail("test@example.com");
        user.setPassword("password");
        user.setVerified(true);

        loginDto = new LoginDto();
        loginDto.setEmail("test@example.com");
        loginDto.setPassword("password");

        userDto = new UserDto();
        userDto.setEmail("newemail@example.com");
        userDto.setPhone("1234567890");
        userDto.setUsername("newusername");
    }

//    @Test
//    void testAddNewUser_UserAlreadyExists() {
//        when(userDao.findUserByEmail(user.getEmail())).thenReturn(user);
//
//        UserException exception = assertThrows(UserException.class, () -> {
//            userService.addNewUser(user);
//        });
//
//        assertEquals("Email already exists", exception.getMessage());
//    }
//
//    @Test
//    void testAddNewUser_Success() {
//        when(userDao.findUserByEmail(user.getEmail())).thenReturn(null);
//        when(userDao.save(user)).thenReturn(user);
//
//        User savedUser = userService.addNewUser(user);
//
//        assertEquals(user, savedUser);
//    }
//
//    @Test
//    void testLogin_UserNotFound() {
//        when(userDao.findUserByEmail(loginDto.getEmail())).thenReturn(null);
//
//        UserException exception = assertThrows(UserException.class, () -> {
//            userService.login(loginDto);
//        });
//
//        assertEquals("Incorrect email or password", exception.getMessage());
//    }
//
//    @Test
//    void testLogin_UserNotVerified() {
//        user.setVerified(false);
//        when(userDao.findUserByEmail(loginDto.getEmail())).thenReturn(user);
//
//        UserException exception = assertThrows(UserException.class, () -> {
//            userService.login(loginDto);
//        });
//
//        assertEquals("Please verify your email.", exception.getMessage());
//    }
//
//    @Test
//    void testLogin_IncorrectPassword() {
//        user.setPassword("wrongpassword");
//        when(userDao.findUserByEmail(loginDto.getEmail())).thenReturn(user);
//
//        UserException exception = assertThrows(UserException.class, () -> {
//            userService.login(loginDto);
//        });
//
//        assertEquals("Incorrect email or password", exception.getMessage());
//    }
//
//    @Test
//    void testLogin_Success() {
//        when(userDao.findUserByEmail(loginDto.getEmail())).thenReturn(user);
//
//        User loggedInUser = userService.login(loginDto);
//
//        assertEquals(user, loggedInUser);
//    }

    @Test
    void testViewUserByEmail() {
        when(userDao.findUserByEmail(loginDto.getEmail())).thenReturn(user);

        User foundUser = userService.viewUserByEmail(loginDto);

        assertEquals(user, foundUser);
    }

    @Test
    void testUpdateUser_UserNotFound() {
        when(userDao.findById(user.getId())).thenReturn(Optional.empty());

        UserException exception = assertThrows(UserException.class, () -> {
            userService.updateUser(userDto, user.getId());
        });

        assertEquals("User not found with Id", exception.getMessage());
    }

    @Test
    void testUpdateUser_Success() {
        when(userDao.findById(user.getId())).thenReturn(Optional.of(user));
        when(userDao.save(user)).thenReturn(user);

        User updatedUser = userService.updateUser(userDto, user.getId());

        assertEquals(userDto.getEmail(), updatedUser.getEmail());
        assertEquals(userDto.getPhone(), updatedUser.getPhone());
        assertEquals(userDto.getUsername(), updatedUser.getUsername());
    }

    @Test
    void testBoughtCars_UserNotFound() {
        when(userDao.findById(user.getId())).thenReturn(Optional.empty());

        UserException exception = assertThrows(UserException.class, () -> {
            userService.boughtCars(user.getId());
        });

        assertEquals("user not found with respective Id", exception.getMessage());
    }

    @Test 
    void testBoughtCars_Success() {
        when(userDao.findById(user.getId())).thenReturn(Optional.of(user));

        Collection<Transaction> transactions = userService.boughtCars(user.getId());

        assertEquals(user.getBoughtCars(), transactions);
    }
}

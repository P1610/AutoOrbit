package com.project.carventure.transaction;

public class TransactionException extends RuntimeException {

	public TransactionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

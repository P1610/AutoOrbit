package com.project.carventure.inventory;

public class InventoryException extends RuntimeException {

	public InventoryException(String message) {
		super(message);
	}

}

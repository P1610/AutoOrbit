package com.project.carventure.location;

public interface LocationService {

	Location addNewLocation(Location location);

	Location getLocation();

}

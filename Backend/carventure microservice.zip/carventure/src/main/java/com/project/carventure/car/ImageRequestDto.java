package com.project.carventure.car;

public class ImageRequestDto {

	private String image;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

}

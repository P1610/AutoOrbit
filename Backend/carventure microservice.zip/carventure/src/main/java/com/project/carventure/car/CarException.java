package com.project.carventure.car;

public class CarException extends RuntimeException {

	public CarException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

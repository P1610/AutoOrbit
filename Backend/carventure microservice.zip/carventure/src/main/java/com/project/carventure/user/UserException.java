package com.project.carventure.user;

public class UserException extends RuntimeException {

	public UserException(String message) {
		super(message);
	}

}

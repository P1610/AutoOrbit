package com.project.carventure.testdrive;

public class TestDriveException extends RuntimeException {

	public TestDriveException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

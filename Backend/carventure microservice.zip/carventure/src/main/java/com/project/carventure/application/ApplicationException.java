package com.project.carventure.application;

public class ApplicationException extends RuntimeException {

	public ApplicationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

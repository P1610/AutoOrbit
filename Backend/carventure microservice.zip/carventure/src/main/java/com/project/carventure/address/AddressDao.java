package com.project.carventure.address;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressDao extends JpaRepository<UserAddress, Integer> {

}

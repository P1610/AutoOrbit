package com.project.carventure.address;

public interface AddressService {

	public Boolean addAddress(UserAddress address, Integer userId);
}

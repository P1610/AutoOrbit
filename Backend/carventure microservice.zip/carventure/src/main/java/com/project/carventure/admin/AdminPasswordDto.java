package com.project.carventure.admin;

public class AdminPasswordDto {

	private String password;

	public AdminPasswordDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminPasswordDto(String password) {
		super();
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}

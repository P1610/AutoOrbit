package com.project.carventure.transaction;

import java.util.Collection;

public interface TransactionService {

	public Collection<Transaction> viewSoldCars();

}
